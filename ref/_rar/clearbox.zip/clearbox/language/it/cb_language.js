//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='avanti',				// text of previous image
	CB_NavTextNxt='indietro',					// text of next image
	CB_NavTextFull='formato originale',				// text of original size (only at pictures)
	CB_NavTextOpen='nuova finestra',		// text of open in a new browser window
	CB_NavTextDL='scarica',				// text of download picture or any other content
	CB_NavTextClose='chiudi',			// text of close CB
	CB_NavTextStart='presentazione',			// text of start slideshow
	CB_NavTextStop='ferma presentazione',			// text of stop slideshow
	CB_NavTextRotR='90 gradi a destra',	// text of rotation right
	CB_NavTextRotL='90 gradi a sinistra'	// text of rotation left
	CB_NavTextReady='clearbox is ready'			// text of clearbox ready

;