//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='zurück',					// text of previous image
	CB_NavTextNxt='weiter',					// text of next image
	CB_NavTextFull='volle grösse',				// text of original size (only at pictures)
	CB_NavTextOpen='in neuem Browser-Fenster öffnen',	// text of open in a new browser window
	CB_NavTextDL='herunterladen',				// text of download picture or any other content
	CB_NavTextClose='schliessen',				// text of close CB
	CB_NavTextStart='Diaschau starten',			// text of start slideshow
	CB_NavTextStop='Diaschau stoppen',			// text of stop slideshow
	CB_NavTextRotR='Bild 90 grad nach rechts drehen',	// text of rotation right
	CB_NavTextRotL='Bild 90 grad nach links drehen',	// text of rotation left
	CB_NavTextReady='clearbox is ready'			// text of clearbox ready

;